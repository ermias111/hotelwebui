import { Component, OnInit } from '@angular/core';
import { RoomService } from 'app/room.service';
import { Room } from 'app/room.model';
import { Response } from '@angular/http';
import { RoomType } from 'app/room-type.model';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css']
})
export class ServicesComponent implements OnInit {
  rooms : Room[] = [];
  roomtypes : RoomType[] = [];

  check = false;

  constructor(private roomService : RoomService) { 
    roomService.read_data().then(resp =>{
      this.rooms = resp;
      console.log(resp[0].RoomId);
    });

    roomService.read_data_rT().then(resp => {
      this.roomtypes = resp;
      console.log(resp[0].Description);
    });
  }
  change_reservation(id : Number){
    console.log("This is my id",id);
      for(var i=0;i<this.rooms.length;i++){
        if(id == this.rooms[i]["RoomId"]){
             this.roomService.update_data(this.rooms[i]["RoomId"]).subscribe(
              (response: Response) => {
                this.roomService.read_data().then(resp =>{
                  this.rooms = resp;
                })
              }
             );
            
        }
      }
  }

  ngOnInit() {
  }

}
