import { Component, OnInit } from '@angular/core';
import { User } from 'app/user.model';
import { Room } from 'app/room.model';
import { RoomService } from 'app/room.service';
import { UserService } from 'app/user.service';
import { Router } from '@angular/router';
import { RoomType } from 'app/room-type.model';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {
  Rooms : Room [] = [];
  RoomTypes : RoomType [] = [];
  counter : number = 0;
  NumberofRooms : number = 0;
  index : number[] = [];
  ErrorMessage: String = "";
  main_counter : String = "";
  signupUsers = new User();
  constructor(private roomService : RoomService,private userService : UserService,private router : Router) {

    roomService.read_data().then((resp) => {
            this.Rooms = resp;
    });

    roomService.read_data_rT().then((resp) => {
            this.RoomTypes = resp;
    });

   }

   selectChangeHandler(event : any){
      if(event.target.value == "Gold"){
        this.signupUsers.RoomtypeId = this.RoomTypes[0].RoomTypeId;
        console.log(this.signupUsers.RoomtypeId);
      }else if(event.target.value == "Epic"){
        this.signupUsers.RoomtypeId = this.RoomTypes[1].RoomTypeId;
      }else if(event.target.value == "Normal"){
        this.signupUsers.RoomtypeId = this.RoomTypes[2].RoomTypeId;
      }    
   }

   checkNumber(){

   }

  signup(y: Number , q: number){
    this.ErrorMessage = "";
    this.main_counter = "";
    this.NumberofRooms = q;
    console.log("its working");
    console.log(this.signupUsers);
    console.log(this.NumberofRooms);
    console.log(this.Rooms);
    // console.log(this.Rooms[0].RoomtypeId);
    for(var x=0;x<this.Rooms.length;x++){
        if(this.Rooms[x].LastState == "Free" && this.RoomTypes[parseInt(this.Rooms[x].RoomtypeId.toString(),10)].RoomTypeId == y){
                this.counter= this.counter + 1;
                this.index.push(x);
        }
      
    }
    

  console.log("This is the counter",this.counter);
  console.log(this.RoomTypes[0].RoomTypeId)
  if(this.counter >= this.NumberofRooms){
        this.Reserve();
  }
  else{
      this.ErrorMessage = "No Rooms Available in number of Rooms you sumbitted";
      this.main_counter = "Only " + this.counter + " Rooms available" ;
  }
}

Reserve(){
  for(var x=0;x< this.NumberofRooms;x++){
  this.roomService.update_data(this.Rooms[this.index[x]]["RoomId"]).subscribe((res)=>{
    if(res.json().msg == "Succesfully Updated"){
        console.log("successfully updated");
    }
    else{
      console.log("Not Updated");
    }
  });
  this.userService.registerUser(this.signupUsers).toPromise().then((res)=>{
        console.log("This is response",res);
        this.router.navigate(['/successreservation']);
  })
}
}

  ngOnInit() {
  }

}
