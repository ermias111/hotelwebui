import { RoomType } from "./room-type.model";

export class Room{
    RoomId:Number;
    RoomtypeId:Number;
    Description:String;
    LocationCode:String;
    PhoneNumber:String;
    Area:Number;
    LastState:String;
    Remark:String;

    constructor(id:Number,room_type:Number,room_description:String,LocationCode:String,
                    PhoneNumber:String,Area:Number,laststate:string,remark:string
        ){
        this.RoomId = id;
        this.RoomtypeId = room_type;
        this.Description = room_description;
        this.LocationCode = LocationCode;
        this.PhoneNumber = PhoneNumber;
        this.Area = Area;
        this.LastState = laststate;
        this.Remark = remark
    }
}