export class RateType {
    RateTypeId : Number;
    Description : String;
    Hourly : String;
    Day : Number;
    Remark : String;

    constructor(rateTypeId : Number,
        description : String,
        hourly : String,
        day : Number,
        remark : String){
            this.RateTypeId = rateTypeId;
            this.Description = description;
            this.Hourly = hourly;
            this.Day = day;
            this.Remark = remark;
    }
}
