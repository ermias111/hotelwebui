import { Injectable } from '@angular/core';
import { User } from 'app/user.model';
import { Observable } from "rxjs/Observable";
import { Http, RequestOptions, Headers, Response } from "@angular/http";

@Injectable()
export class UserService {

 

  http: Http;
  constructor(http: Http) {
    this.http = http;
     
}
registerUser(userModel: User): Observable<Response> {
  var requestOptions = new RequestOptions();
  requestOptions.headers = new Headers();
  requestOptions.headers.append("Content-Type", "application/json");
  var requestBody = JSON.stringify(userModel);
  console.log("This is from the user service and this is my object ", JSON.stringify(userModel));
  return this.http.post("http://localhost:32490/reservation", JSON.stringify(userModel), requestOptions);
}

}


