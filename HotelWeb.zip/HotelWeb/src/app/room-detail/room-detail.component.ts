import { Component, OnInit } from '@angular/core';
import { RoomService } from 'app/room.service';
import { Room } from 'app/room.model';
import { RoomRate } from 'app/room-rate.model';
import { RoomType } from 'app/room-type.model';

@Component({
  selector: 'app-room-detail',
  templateUrl: './room-detail.component.html',
  styleUrls: ['./room-detail.component.css']
})
export class RoomDetailComponent implements OnInit {
  id:Number;
  roomToBeListed : Room[] = [];
  roomRate  : RoomRate []= [];
  roomType  : RoomType [] = [];
  rooms : Room [] = [];

  constructor(private roomService : RoomService) { 
    this.roomService.read_data().then((res)=>{
      this.rooms = res;
      this.roomService.read_data_rT().then((restype)=>{
        this.roomType = restype;
    this.roomService.read_data_room_rate().then((resrate)=>{  
      this.roomRate = resrate; 
      console.log(this.roomRate); 

          this.roomService.roomClicked.subscribe((x:Number)=>{
            this.id= x;
            console.log("I have recieved this id",x);
            this.find_room(res);
    });
    });
  });
});
    
  }
  find_room(res){
    this.roomToBeListed = [];
    for(var x=0;x<res.length;x++){
      if(res[x]["RoomId"] == this.id){
        this.roomToBeListed.push(res[x]);
      }
      console.log("this is the roomtobe Listed",this.roomToBeListed);
      console.log(res);
  }

  }


  ngOnInit() {
  }

}
