export class RoomRate {
    RoomRateId : Number;
    RoomTypeId : Number;
    RateTypeId :Number;
    TagTypeId : Number;
    TagTextValue : string;
    TagValue : string;
    Amount : Number;
    ExtraAdult : Number;
    ExtraChild : Number;
    Priority : Number;
    isWeekend : Boolean;
    Remark : string;

    constructor( roomRateId : Number,
        roomTypeId : Number,
        rateTypeId :Number,
        tagTypeId : Number,
        tagTextValue : string,
        tagValue : string,
        amount : Number,
        extraAdult : Number,
        extraChild : Number,
        priority : Number,
        isWeekend : Boolean,
        remark : string){
            this.RoomRateId = roomRateId;
            this.RoomTypeId = roomTypeId;
            this.RateTypeId = rateTypeId;
            this.TagTypeId = tagTypeId;
            this.TagTextValue = tagTextValue;
            this.TagValue = tagValue;
            this.Amount = amount;
            this.ExtraAdult = extraAdult;
            this.ExtraChild = extraChild;
            this.Priority = priority;
            this.isWeekend = isWeekend;
            this.Remark = remark;
        }


}
