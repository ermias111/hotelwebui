import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { Routes,RouterModule} from '@angular/router';
import { HomePageComponent } from './home-page/home-page.component';
import { ServicesComponent } from './services/services.component';
import { ContactComponent } from './contact/contact.component';
import { AboutComponent } from './about/about.component';
import { RoomService } from './room.service';
import { LoginPageComponent } from './login-page/login-page.component';
import { SuccessReservationComponent } from './success-reservation/success-reservation.component';
import { UserService } from './user.service';
import { RoomDetailComponent } from './room-detail/room-detail.component';

const appRoutes:Routes = [
  {path : '',component : HomePageComponent},
  {path : 'services',component : ServicesComponent},
  {path : 'about',component : AboutComponent},
  {path : 'contact',component : ContactComponent},
  {path : 'loginpage',component : LoginPageComponent},
  {path : 'successreservation',component : SuccessReservationComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    ServicesComponent,
    ContactComponent,
    AboutComponent,
    LoginPageComponent,
    SuccessReservationComponent,
    RoomDetailComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [RoomService,UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
