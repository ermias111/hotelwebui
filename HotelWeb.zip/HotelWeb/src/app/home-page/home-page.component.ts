import { Component, OnInit } from '@angular/core';
import { RoomService } from 'app/room.service' 
import { Room } from 'app/room.model';
import { RoomType } from 'app/room-type.model';
import { RoomRate } from 'app/room-rate.model';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {
  rooms :Room[] = [];
  roomType : RoomType[] = [];
  roomRate : RoomRate [] = [];

  constructor(private roomService : RoomService) {
    this.roomService.read_data_rT().then((res)=>{
        this.roomType = res;
    this.roomService.read_data_room_rate().then((resrate)=>{  
      this.roomRate = resrate; 
      console.log(this.roomRate); 
        
    this.roomService.read_data().then((resp)=>{
      
     
      for(var x = 0;x<resp.length;x++){
          if(resp[x].RoomtypeId == 0){
                this.rooms.push(resp[x]);
                break;
           }
      }
      for(var x = 0;x < resp.length;x++){
        if(resp[x]["RoomtypeId"] == 1){
             this.rooms.push(resp[x]);
             break;
        }
      
      }
      for(var x = 0;x < resp.length;x++){
        if(resp[x]["RoomtypeId"] == 2){
            this.rooms.push(resp[x]);
            break;
           
        }
      }
    console.log("This is the Full Array",resp);
    console.log("This is the final array",this.rooms);
    });
  });

});
   }

   onSelect(x: Number){
     console.log("Im sending this id",x);
        this.roomService.roomClicked.emit(x);
   }


  


  ngOnInit() {
  }

}
