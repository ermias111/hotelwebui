import { Injectable ,EventEmitter } from '@angular/core';
import {Http } from '@angular/http';
import { Room} from './room.model';
import { RoomType } from './room-type.model';
import { RoomRate } from './room-rate.model';
import { RateType } from './rate-type';

@Injectable()
export class RoomService {
  room : Room [] = [];
  roomTypes : RoomType [] = [];
  roomRates : RoomRate [] = [];
  rateTypes : RateType [] = [];

  roomClicked = new EventEmitter<Number>();

  constructor(private http:Http) {
    

   }


read_data() : Promise<Room []>{
  return this.http.get("http://localhost:32490/room").toPromise().
  then((response) => {
      console.log(response.json());
      return this.jsonConverter(response.json());
  })
}

read_data_rT(){
  return this.http.get("http://localhost:32490/roomtype").toPromise().
  then((response) => {
      console.log(response.json());
      return this.jsonConverterT(response.json());
  })
}

read_data_room_rate(){
  return this.http.get("http://localhost:32490/roomrate").toPromise().
  then((response) => {
      console.log(response.json());
      return this.jsonConverterRoomRate(response.json());
  })
}

read_data_rate_type(){
  return this.http.get("http://localhost:32490/ratetype").toPromise().
  then((response) => {
      console.log(response.json());
      return this.jsonConverterRateType(response.json());
  })
}

update_data(room_id : Number){
  var reserved = "Yes";
  console.log("This is from Service",room_id)
  return this.http.put(`http://localhost:32490/room/${room_id}`,{reserved : reserved});
}


jsonConverter(resp){
  var tmp : Room[] = [];
  for(var i=0;i<resp.length;i++){
          tmp.push(new Room(resp[i]["roomId"],resp[i]["roomtypeId"],resp[i]["description"],resp[i]["phoneNumber"],resp[i]["locationCode"],resp[i]["area"],
          resp[i]["lastState"],resp[i]["remark"]));
  }
  this.room = tmp;
  console.log(this.room);
  return this.room;
}

jsonConverterT(resp){
  var tmp : RoomType[] = [];
  for(var i=0;i<resp.length;i++){
          tmp.push(new RoomType(resp[i]["roomTypeId"],resp[i]["roomRateId"],resp[i]["description"],resp[i]["numberOfRooms"],resp[i]["index"],resp[i]["maxChildren"],resp[i]["maxOccupancy"],
          resp[i]["roomImage"],resp[i]["active"], resp[i]["remark"]));
  }
  this.roomTypes = tmp;
  console.log(this.roomTypes);
  return this.roomTypes;
}

jsonConverterRoomRate(resp){
  var tmp : RoomRate[] = [];
  for(var i=0;i<resp.length;i++){
          tmp.push(new RoomRate(resp[i]["roomRateId"],
            resp[i]["roomTypeId"],
            resp[i]["rateTypeId"],
            resp[i]["tagTypeId"] ,
            resp[i]["tagTextValue"],
            resp[i]["tagValue"],
            resp[i]["amount"],
            resp[i]["extraAdult"],
            resp[i]["extraChild"] ,
            resp[i]["priority"],
            resp[i]["isWeekend"],
            resp[i]["remark"]
        ));
  }
  this.roomRates = tmp;
  console.log(this.roomRates);
  return this.roomRates;
}

jsonConverterRateType(resp){
  var tmp : RateType[] = [];
  for(var i=0;i<resp.length;i++){
          tmp.push(new RateType(
            resp[i]["RateTypeId"] ,
            resp[i]["Description"],
            resp[i]["Hourly"],
            resp[i]["Day"] ,
            resp[i]["Remark"] ));
  }
  this.rateTypes = tmp;
  console.log(this.rateTypes);
  return this.rateTypes;
}

}