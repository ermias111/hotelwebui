export class RoomType {
    RoomTypeId : Number;
    RoomRateId: Number;
    Description : String;
    NumberOfRooms : Number;
    index : Number;
    MaxOccupancy : Number;
    MaxChildren : Number;
    RoomImage : String;
    Active : Boolean;
    Remark : String;

    constructor(roomtypeid: Number,roomrateId: Number, description : String, numberofrooms : Number
        , index: Number, maxoccupancy : Number, maxchildren :Number, roomimage : String
        , active: Boolean, remark : String ){
            this.RoomTypeId = roomtypeid;
            this.RoomRateId = roomrateId;
            this.Description = description;
            this.NumberOfRooms = numberofrooms;
            this.index = index;
            this.MaxChildren = maxchildren;
            this.MaxOccupancy = maxoccupancy;
            this.RoomImage = roomimage;
            this.Active = active;
            this.Remark = remark;
    }
}
