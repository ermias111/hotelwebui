import { RoomType } from "./room-type.model";

export class User{
    first_name : String;
    last_name : String;
    RoomtypeId : Number;
    check_in_date: String;
    check_out_date: String;

    constructor(){

    }
}
