import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-success-reservation',
  templateUrl: './success-reservation.component.html',
  styleUrls: ['./success-reservation.component.css']
})
export class SuccessReservationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
