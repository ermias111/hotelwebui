var mongoose = require('mongoose');
var schema = mongoose.Schema;

var room_schema =  new schema ({
    room_img:String,
    room_description:String,
    room_type:String,
    room_price:Number,
    room_size:Number,
    room_benefits:String,
    room_reserved:String
},{versionKey:false});
var room = mongoose.model('rooms',room_schema);
module.exports = room;