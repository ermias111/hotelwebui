module.exports = {
    'secret':'my application secrets',
    'database': 'mongodb://127.0.0.1/room_services'
  };
  