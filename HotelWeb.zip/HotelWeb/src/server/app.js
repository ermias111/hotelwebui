var express = require('express');
var mongoose = require('mongoose');
var room = require('./services');
var user = require('./user');
var bodyParser = require('body-parser');
var config =  require('./config/database');

var app = express();
mongoose.connect(config.database);

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));


app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "http://localhost:4200");
    res.header('Access-Control-Allow-Credentials', 'true');
    res.header("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE");
    res.header("Access-Control-Allow-Headers", " *");
    res.header("Access-Control-Allow-Headers", "Orgin, X-Requested-with,Content-Type,Accept");
    next();
  });

app.post("/signup",function(req,res){
    var users = res.body();
    var newuser = new user({
        username: users.username,
        password: users.password,
        firstname : users.firstname,
        lastname : users.lastname,
        emergencycontactname : users.emergencycontactname,
        emergencycontact : users.emergencycontact
    })
    newuser.save(function(err){
       if (err) return handleError(err);
    });
});

app.get("/login",function(req,res){
    var username_ = req.params['username'];
    var password_ = req.params['password'];
    room.find({username: username_ , password : password_},function(req,res){
        if(err) throw "Incorrect username or password"
        res.status(200).send("Successfully Logged in");
    }
        );

});

app.get("/read_room",function (req,res){
    console.log("Im reading");
    room.find({},function (err,main){
        if (err) throw err;
        res.status(200).send(main);
    })
});
app.post("/add_room",function(req,res){
    var rooms = res.body;
    var newRoom = new room({
        room_img:rooms.room_img,
        room_description:rooms.room_description,
        room_type:rooms.room_type,
        room_price:rooms.room_price,
        room_size:rooms.room_size,
        room_benefits:rooms.room_benefits,
        room_reserved:rooms.room_reserved
    });
});
app.get("/remove_room",function(req,res){
    var remove = req.query['remove'];
    room.deleteOne({ _id:remove},function(err){
        if(err) throw err;
        res.status(200).send("Successfully Deleted")
    });
});

app.put("/update_room/:room_id", function(req,res){
    var room_id = req.params['room_id'];
    console.log("This is from Api",room_id);
    var reserved = req.body['reserved'];
    console.log("This is from Api Reserved")
    room.findByIdAndUpdate(
        room_id,{room_reserved:reserved},function(err,room){
            if(err) outputMessageAndEndResponse(res,'database error Occurred');
            else if(!room) outputMessageAndEndResponse(res,'Could not find room');
            else outputMessageAndEndResponse(res, 'Succesfully Updated');
        });
});

function outputMessageAndEndResponse(res, msg) {
    console.log(msg);
    res.end();
}

//    var first_one = room({
//        room_img:"../src/img/Room.jpg",
//        room_description: "This room is more luxiourious than Normal room",
//        room_type:"Epic",
//        room_price:15000,
//        room_size:2,
//        room_benefits:"Free Food and drinks",
//        room_reserved:"No"
//   });

//     first_one.save(function(err){
//      if (err) return handleError(err);
//    });



  app.listen(3000);
