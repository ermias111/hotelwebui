var mongoose = require('mongoose');
var schema = mongoose.Schema;

var user_schema =  new schema(
 {
     username : {
        type:String,
        required: true,
        unique: true
    },
     password : {
         type:String,
         required: true,
         
     },
     firstname : String,
     lastname : String,
     emergencycontactname : String,
     emergencycontact : String
},{
    versionKey:false
});
var user = mongoose.model('users',user_schema);
module.exports = user;